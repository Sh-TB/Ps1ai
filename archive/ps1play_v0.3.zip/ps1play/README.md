# ps1play — Agentic PS1 Gaming Base (پایهٔ ایجنتی بازی‌های PS1)

A universal, plugin-based tool that runs PS1 games headless and lets ANY AI
agent play them like a human — by reading **RAM bytes** (not pixels), injecting
**only button inputs** (no memory writes = no cheats), and **continuing from
where it left off**.

## Proven pipeline (v0.3, Metal Slug X SLUS-01212)

```
boot  ->  enter_gameplay3  ->  calibrate  ->  play (events)  ->  resume
```

1. **Deterministic boot** — the Task-2 START-tap timeline (1000..5200 every
   300f + the 5150 OK?/YES confirm) drives title → menu → soldier-select →
   MISSION 1. Acceptance is gated by the **trajectory test**: from one
   savestate, play 3 different input scripts — a scripted attract demo stays
   byte-identical; a real mission diverges. Zero pixels, zero tokens.
2. **Per-boot calibration** (scripts/calibrate.py) — the game's RAM layout
   SHIFTS between boots, so the watch list is re-derived every boot from
   signature events, strictly read-only (classic GameShark cheat-FINDER
   workflow, savestate-deterministic):
   - bombs: starts 8..15, decrements by exactly 1 on a circle-throw
   - hp: starts 90..110 or 190..215 (scale varies!), drops on a melee stab
   - timer: 1 Hz countdown (dec_by 5±1 over 300f, two passes)
   - candidates in the game's counter zone (~0xEE000-0xF0000) get priority
3. **Live play** — the plugin policy (advance + tap-fire + hop + dodge +
   grenade on clusters + START after death) runs from RAM telemetry only:
   events like `hit / grenade_used / healed_or_respawn / death` are pure
   RAM deltas. Measured in the last session: 132 hits, 160 grenades, 23
   hp-resets over 20400 frames at ~385 fps (no GPU, no X11).

## Architecture

```
ps1play/
├── core/
│   ├── host.py       Libretro host (ctypes): boots game, live RAM/VRAM views,
│   │                 save-states, input injection. No GPU/X11 needed.
│   ├── memory.py     MemoryView (u8/u16/u32), digests, structural diff
│   ├── statemgr.py   Save states + JSONL journal (continue-anywhere)
│   └── inputmap.py   PSX pad constants & parsing  (BUGFIX: {"START"} sets!)
├── agent/
│   ├── observer.py   Token-minimal telemetry (digest + changed regions)
│   ├── discovery.py  Game-agnostic probes: diff / correlate / verify_series
│   │                 / input_echo / monotonic
│   ├── memscan.py    RetroArch/BizHawk-style cheat-finder (READ-ONLY):
│   │                 scan -> narrow (eq/lt/inc/dec/changed...) -> results
│   ├── gsmap.py      Published GameShark knowledge (gamehacking.org) as
│   │                 READ-ONLY seeds + the pad-bit map
│   ├── entities.py   Entity-slot discovery (live actor fields -> blocks)
│   ├── nav.py        ThumbNav: 64x48 gray thumbnails -> menu state -> action
│   └── loop.py       sense → decide → act loop + checkpoints
├── plugins/
│   └── base.py       GamePlugin (boot/features/policy) + MetalSlugXPlugin
├── profiles/         Per-game JSON: gsmap (watch list), history, nav refs
└── api.py            PS1Play — the one class every agent needs
scripts/
├── psx_headless.py   Task-2 proof frontend (the proven boot timeline)
├── verify_gsmap.py   Live verification of the watch list + x/y scans
├── calibrate.py      Per-boot semantic recalibration (see above)
├── play_v2.py        The real play session (calibrate -> play -> resume)
├── flow_probe*.py    The bisection experiments that mapped the boot flow
└── diag_pad*.py      Pad-mirror investigations
```

## Agent API (all outputs are compact JSON — minimal tokens)

```python
from ps1play.api import PS1Play

p = PS1Play(game="Metal Slug X (USA).cue").boot()
r = p.enter_gameplay3()      # proven timeline + trajectory proof -> in_game
p.play(6000)                 # plugin policy plays; journal + checkpoints
p.save_state("stage1")       # ...later, even in a new process:
p.load_state("stage1")       # continue exactly where you left off
p.report()                   # small JSON summary for the LLM
```

## Lessons burned into the code (so we never re-learn them)

- `parse_buttons({"START"})` used to pass STRINGS through — **the whole
  stack was playing with dead inputs**. Fixed: name-sets convert to ids.
- The OK?/YES box confirms on **B (cross)**; START does nothing there.
- START after the menu **pauses the mission**; pause-menu navigation quits
  to title — never punch START once the menu phase is done.
- The attract demo's mission-1 scenes have a bright snow band — a naive
  "white text" detector misfires on it; the white gate is only for the
  coin-up "PRESS 1P OR 2P START" screens.
- Published GameShark addresses for this game **do not match this dump's
  revision** and the layout **shifts per boot** — treat addresses as
  session-local, keep the scan RECIPES.

## Requirements

- Python 3.12+, numpy, Pillow (only for optional human-reference PNGs)
- A libretro PS1 core (Beetle PSX / mednafen_psx — tested with 0.9.44.1)
- PS1 BIOS in `<workspace>/system/` (for NTSC-U games: `scph5501.bin`)
- The game as `.cue/.bin`

## Honest status / next steps

- ✅ deterministic boot to MISSION 1 with a cryptographic control proof
- ✅ per-boot calibrated telemetry: hp / bombs / timer / player_y live
- ✅ event-driven policy loop (dodge/grenade/death-recovery) with
  checkpoints + resume; evidence PNGs + JSON reports
- ⬜ player_x discovery (the camera scrolls; the player's screen-x barely
  moves — needs a camera-x model)
- ⬜ survival policy iteration (the current basic policy clears the first
  enemy groups but dies at the bridge); weapon-pickup handling
- ⬜ enemy-pattern extraction into the profile (entities.py is ready)
